package eleicoes;

public class ContagemVotos {
    int validos;
    int invalidos;
    
    ContagemVotos(int validos, int invalidos) {
        this.validos = validos;
        this.invalidos = invalidos;
    } // Construtor da classe. 
}
